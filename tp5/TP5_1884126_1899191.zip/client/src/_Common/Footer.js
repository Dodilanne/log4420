
export function Footer() {
  return (
    <footer>
        <p>Par Vincent Audet et Pablo Chaussé-Cossio</p>
    </footer>
  );
}

